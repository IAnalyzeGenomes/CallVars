"""gatktool package

Modules with functions and classes for extending GATK tools with Python.

"""
